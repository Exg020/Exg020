package com.example.hw5;

import java.util.Objects;
import java.util.Optional;

/**
 * This class was created to store the attributes for an Address from the database
 */
public class Address {
    /**
     * This is the id for every address
     */
    private int addressId;

    /**
     * This stores the first Name from the address
     */
    private String firstName;

    /**
     * This stores the Middle initial from the address
     */
    private char middleInitial;

    /**
     * This stores the last name from the address
     */
    private String lastName;

    /**
     * this stores the street from the address
     */
    private String street;

    /**
     * This stores the city from the address
     */
    private String city;

    /**
     * This stores the state from the address
     */
    private String state;

    /**
     * This stores the zip from the address
     */
    private int zip;

    /**
     * This stores the telephone from the address
     */
    private int telephone;

    /**
     * This stores the email from the address
     */
    private String email;

    /**
     * This is the const AddressDAO to call the DAOFactory for an SQLite file
     */
    private static final AddressDAO DAO = DAOFactory.getDAOFactory(DAOFactory.SQLITE).getAddressDAO();

    /**
     * Constructs and initializes an Address with its values. No Null Values
     * @param firstName is the string value for the first name in address
     * @param middleInitial is the Char value for middle Initial
     * @param lastName is the string value for last name
     * @param street is the string value for street
     * @param city is the string value for city
     * @param state is the string value for the state
     * @param zip is the int value for zip
     * @param telephone is the int value for telephone
     * @param email is the string value for email
     */
    public Address(String firstName,char middleInitial,String lastName,String street,String city,String state,int zip,int telephone, String email ){
        Objects.requireNonNull(firstName);
        Objects.requireNonNull(lastName);
        Objects.requireNonNull(street);
        Objects.requireNonNull(state);
        Objects.requireNonNull(email);

        this.firstName = firstName;
        this.middleInitial = middleInitial;
        this.lastName = lastName;
        this.street = street;
        this.city = city;
        this.state = state;
        this.zip = zip;
        this.telephone = telephone;
        this.email = email;
    }

    /**
     * Constructs and initializes an Address with its values but also includes the address id. No Null Values
     * @param addressId is the int value for the address id
     * @param firstName is the string value for the first name in address
     * @param middleInitial is the Char value for middle Initial
     * @param lastName is the string value for last name
     * @param street is the string value for street
     * @param city is the string value for city
     * @param state is the string value for the state
     * @param zip is the int value for zip
     * @param telephone is the int value for telephone
     * @param email is the string value for email
     */
    public Address(int addressId,String firstName,char middleInitial,String lastName,String street,String city,String state,int zip,int telephone, String email ){
        Objects.requireNonNull(firstName);
        Objects.requireNonNull(lastName);
        Objects.requireNonNull(street);
        Objects.requireNonNull(state);
        Objects.requireNonNull(email);

        this.addressId = addressId;
        this.firstName = firstName;
        this.middleInitial = middleInitial;
        this.lastName = lastName;
        this.street = street;
        this.city = city;
        this.state = state;
        this.zip = zip;
        this.telephone = telephone;
        this.email = email;
    }

    /**
     * This method when called returns the address id
     * @return the address id
     */
    public int getAddressId() {
        return this.addressId;
    }

    /**
     * This method when called returns the first name
     * @return first name
     */
    public String getFirstName() {
        return this.firstName;
    }

    /**
     * This method when called sets the first name value for an Address
     * @param firstName is a string value
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * this method when called returns the middle initial
     * @return the middle initial char
     */
    public char getMiddleInitial() {
        return this.middleInitial;
    }

    /**
     * This method is used to set a new char value for middle initial
     * @param middleInitial is the new value
     */
    public void setMiddleInitial(char middleInitial) {
        this.middleInitial = middleInitial;
    }

    /**
     * this method when called is used to return the last name
     * @return the last name string value
     */
    public String getLastName() {
        return this.lastName;
    }

    /**
     * Thie method when called sets a new last name value for the address
     * @param lastName is the new last name value
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * This method when called returns the street value
     * @return the street string value
     */
    public String getStreet() {
        return this.street;
    }

    /**
     * This method is called to set a new street string value
     * @param street new string value
     */
    public void setStreet(String street) {
        this.street = street;
    }

    /**
     * This method is called to get the city string value
     * @return the city string value
     */
    public String getCity() {
        return this.city;
    }

    /**
     * This method when called is used to set a new city value for an address
     * @param city this used to set the new string value
     */
    public void setCity(String city) {
        this.city = city;
    }

    /**
     * This method is used to get the state string value
     * @return the state string value
     */
    public String getState() {
        return this.state;
    }

    /**
     * This method is used to set a new state string value
     * @param state is the new state string value
     */
    public void setState(String state) {
        this.state = state;
    }

    /**
     * This method is used to get the int zip value
     * @return the zip int value
     */
    public int getZip() {
        return this.zip;
    }

    /**
     * This method is used to set a New Zip int
     * @param zip is the new zip int
     */
    public void setZip(int zip) {
        this.zip = zip;
    }

    /**
     * This method is used to get the telephone int value
     * @return telephone int value
     */
    public int getTelephone() {
        return this.telephone;
    }

    /**
     * This method to set a new telephone int value
     * @param telephone is the new int value
     */
    public void setTelephone(int telephone) {
        this.telephone = telephone;
    }

    /**
     * This method is used to return the email string
     * @return email string value
     */
    public String getEmail() {
        return this.email;
    }

    /**
     * This method is used to set the email value
     * @param email string value
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * This method uses the DAO to try and delete an Address from the database
     * @return either true or false if the Address was deleted or not
     * If it fails to reach out to the DAO it will throw a DAOException
     */
    public boolean deleteAddress() {
        try{
            return DAO.deleteAddress(this);
        } catch (DAOException daoException){
            return false;
        }
    }

    /**
     * THis method uses the DAO to try and update an Address in the database
     * @return either true or false if the Address was updated or not
     * If it fails to reach out to the DAO it will throw a DAOException
     */
    public boolean updateAddress() {
        try{
            return DAO.updateAddress(this);
        } catch (DAOException daoException){
            return false;
        }
    }

    /**
     * This method uses the DAO to try and insert a new Address into the database
     * @return either true or false if the Address was inserted or not
     * If it fails to reach out to the DAO it will throw a DAOException
     */
    public boolean insertAddress() {
        try {
            return DAO.insertAddress(this);
        } catch (DAOException daoException){
            return false;
        }
    }

    /**
     * This method calls the DAO to look into the database and search for the Address by its id
     * @param id is the id for the Address that it is searching for
     * @return either an optional Address or an empty
     */
    public static Optional<Address> getById (int id){
        try{
            return Optional.of(DAO.getById(id));
        } catch (DAOException daoException){
            return Optional.empty();
        }
    }

    /**
     * The method returns the hashCode for the values for equals purposes
     * @return hashCode number
     */
    @Override
    public int hashCode(){
        return Objects.hash(this.addressId,this.firstName,this.middleInitial,this.lastName,this.street,this.city,this.state,this.zip,this.telephone,this.email);
    }

    /**
     * The method checks to see if objects are equal to each other
     * @param obj can be any object from any subclass
     * @return if its true or false
     */
    @Override
    public boolean equals(Object obj){
        if(this == obj) return true;
        if(!(obj instanceof Address)) return false;
        var that = (Address) obj;
        return this.addressId == that.addressId && Objects.equals(this.firstName,that.firstName) && this.middleInitial == that.middleInitial && Objects.equals(this.lastName,that.lastName) && Objects.equals(this.street,that.street) &&
              Objects.equals(this.city, that.city) && Objects.equals(this.state,that.state) && this.zip == that.zip && this.telephone == that.telephone && Objects.equals(this.email,that.email);
    }


}
