package com.example.hw5;

/**
 * This DAO Class was created as a custom exception. One universal exception just in case you need to change the DAL
 */
public class DAOException extends Exception {
    /**
     * Constructs and initializes the DAOException
     * @param message is the param message for the exceptin o
     */
    public DAOException(String message){
        super(message);
    }
}
