package com.example.hw5;
/**
 * This Class was created to get all the SQLite DAOs
 */
public class SqliteDAOFactory extends DAOFactory{

    /**
     * This is the const connection string for the Address file
     */
    public static final String URL = "jdbc:sqlite:Address.db";

    /**
     * This method is used to return a CategoryDAO
     * @return a new SqliteAddressDAOImpl();
     */
    @Override
    public AddressDAO getAddressDAO(){
        return new SqliteAddressDAOImpl();
    }

}
