package com.example.hw5;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Optional;
import java.util.Scanner;

public class HelloApplication extends Application {

    /**
     * Const string value for Insert title
     */
    private static final String INSERT_TITLE= "Insert";

    /**
     * Const string value for insert header
     */
    private static final String INSERT_HEADER = "Address Insert Request";

    /**
     * Const string value for new address inserted
     */
    private static final String INSERT_CONTENT = "New Address Inserted!";

    /**
     * Const string value for Delete
     */
    private static final String DELETE_TITLE = "Delete";

    /**
     * Const string value for Address delete request
     */
    private static final String DELETE_HEADER = "Address Delete Request";

    /**
     * Const string value for Address Deleted
     */
    private static final String DELETE_CONTENT = "Address Deleted!";

    /**
     * Const string value for Update
     */
    private static final String UPDATE_TITLE = "Update";

    /**
     * Const string value for Address update request
     */
    private static final String UPDATE_HEADER = "Address Update Request";

    /**
     * Const string value for Address updated
     */
    private static final String UPDATE_CONTENT = "Address Updated!";

    /**
     * Const string value for Invalid
     */
    private static final String INVALID = "Invalid";

    /**
     * Const string value for Last name field error
     */
    private static final String ERROR_LAST_NAME_HEADER = "Last Name Field Error";

    /**
     * Const string value for last name cannot be empty
     */
    private static final String ERROR_LAST_NAME_CONTENT = "Last Name cannot be empty";

    /**
     * Const string value for first name field error
     */
    private static final String ERROR_FIRST_NAME_HEADER = "First Name Field Error";

    /**
     * Const string value for first name cannot be empty
     */
    private static final String ERROR_FIRST_NAME_CONTENT = "First Name cannot be empty";

    /**
     * Const string value for middle initial field error
     */
    private static final String ERROR_MI_HEADER = "Middle Initial Field Error";

    /**
     * Const string value for middle initial cannot be empty and can only be 1 char
     */
    private static final String ERROR_MI_CONTENT = "Middle Initial cannot be empty and can only be 1 char";

    /**
     * Const string value for street field error
     */
    private static final String ERROR_STREET_HEADER = "Street Field Error";

    /**
     * Const string value for street cannot be empty
     */
    private static final String ERROR_STREET_CONTENT = "Street cannot be empty";

    /**
     * Const string value for city field error
     */
    private static final String ERROR_CITY_HEADER = "City Field Error";

    /**
     * Const string value for city field cannot be empty
     */
    private static final String ERROR_CITY_CONTENT = "City field cannot be empty";

    /**
     * Const string value for state field error
     */
    private static final String ERROR_STATE_HEADER = "State Field Error";

    /**
     * Const string value for state cannot be empty and can only be 2 characters
     */
    private static final String ERROR_STATE_CONTENT = "State cannot be empty and can only be 2 characters";

    /**
     * Const string value for zip field error
     */
    private static final String ERROR_ZIP_HEADER = "ZIP Field Error";
    /**
     * Const string value for  zip content error
     */
    private static final String ERROR_ZIP_CONTENT = "Zip cannot be empty and has to be 5 integers";

    /**
     * Const string value for telephone header error
     */
    private static final String ERROR_TELE_HEADER = "Telephone Field Error";

    /**
     * Const string value for telephone content error
     */
    private static final String ERROR_TELE_CONTENT = "Telephone cannot be empty and has to be 10 integers";

    /**
     * Const string value for email field error
     */
    private static final String ERROR_EMAIL_HEADER = "Email Field Error";

    /**
     * Const string value for email field cannot be empty
     */
    private static final String ERROR_EMAIL_CONTENT = "Email Field cannot be empty";

    /**
     * Const string value for address error
     */
    private static final String ERROR_ADDRESS_HEADER = "Address Error";

    /**
     * Const string value for unable to add new address
     */
    private static final String ERROR_ADDRESS_CONTENT = "Unable to add new Address ";

    /**
     * Const string value for not found
     */
    private static final String ERROR_NOT_FOUND_HEADER = "Not Found";

    /**
     * Const string value for no address found with id - %d
     */
    private static final String ERROR_NOT_FOUND_CONTENT = "No address found with id - %d";

    /**
     * Const string value for Delete Error
     */
    private static final String ERROR_DELETE_HEADER = "DELETE ERROR";

    /**
     * Const string value for unable to delete address
     */
    private static final String ERROR_DELETE_CONTENT = "Unable to delete address";

    /**
     * Const string value for update error
     */
    private static final String ERROR_UPDATE_HEADER = "UPDATE ERROR";

    /**
     * Const string value for unable to update address
     */
    private static final String ERROR_UPDATE_CONTENT = "Unable to update address";

    /**
     * Const string value for next address
     */
    private static final String ERROR_NEXT_HEADER = "Next Address";

    /**
     * Const string value for Error, there are no more addresses
     */
    private static final String ERROR_NEXT_CONTENT = "Error, There are no more addresses";

    /**
     * Const string value for Prior address
     */
    private static final String ERROR_PRIOR_HEADER = "Prior Address";

    /**
     * Const string value for error, there are no more addresses
     */
    private static final String ERROR_PRIOR_CONTENT = "Error, There are no more addresses";

    /**
     * Const int value for middle initial size
     */
    private static final int MIDDLE_INITIAL_SIZE = 1;

    /**
     * Const int value for State string size
     */
    private static final int STATE_SIZE = 2;

    /**
     * Const int value for Zip size
     */
    private static final int ZIP_SIZE = 5;

    /**
     * Const int value for telephone size
     */
    private static final int TELE_SIZE =10;


    /**
     * Const string value for first
     */
    private static final String FIRST_BUTTON = "First";

    /**
     * Const string value for next
     */
    private static final String NEXT_BUTTON = "Next";

    /**
     * Const string value for prior
     */
    private static final String PRIOR_BUTTON = "Prior";

    /**
     * Const string value for Last
     */
    private static final String LAST_BUTTON = "Last";

    /**
     * Const string value for Last name
     */
    private static final String LABEL_LAST_NAME = "Last Name";

    /**
     * Const string value for first name
     */
    private static final String LABEL_FIRST_NAME = "First Name";

    /**
     * Const string value for MI
     */
    private static final String LABEL_MI = "MI";

    /**
     * Const string value for Street label
     */
    private static final String LABEL_STREET = "Street";

    /**
     * Const string value for City label
     */
    private static final String LABEL_CITY = "City";

    /**
     * Const string value for State label
     */
    private static final String LABEL_STATE = "State";

    /**
     * Const string value for Zip label
     */
    private static final String LABEL_ZIP = "ZIP";

    /**
     * Const string telephone label
     */
    private static final String LABEL_TELE = "Telephone";

    /**
     * Const string value for email label
     */
    private static final String LABEL_EMAIL = "Email";

    /**
     * Const string value for Current row id label
     */
    private static final String LABEL_CURRENT_ROW = "Current Row ID :";

    /**
     * Const string value for the form title
     */
    private static final String FORM_TITLE = "Address Form";

    /**
     * Const for the lastNameTextfield
     */
    private final TextField lastNameTextField = new TextField();

    /**
     * Const for the firstNameTextField
     */
    private final TextField firstNameTextField = new TextField();

    /**
     * Const for the middleInitialTextField
     */
    private final TextField middleInitialTextField = new TextField();

    /**
     * Const for the streetTextField
     */
    private final TextField streetTextField = new TextField();

    /**
     * Const for the cityTextField
     */
    private final TextField cityTextField = new TextField();

    /**
     * Const for the stateTextField
     */
    private final TextField stateTextField = new TextField();

    /**
     * Const for zipTextField
     */
    private final TextField zipTextField = new TextField();

    /**
     * Const for teleTextField
     */
    private final TextField teleTextField = new TextField();

    /**
     * Const for the emailTextField
     */
    private final TextField emailTextField = new TextField();

    /**
     * Const for the currentRowLabel
     */
    private final Label currentRowLabel = new Label("");

    /**
     * Const for an empty string
     */
    private static final String EMPTY_STRING = "";

    /**
     * Const for the main addressList list
     */
    private static final AddressList ADDRESS_LIST = new AddressList(new ArrayList<>());

    /**
     * This method is called to load all the addresses into the ADDRESS_LIST
     */
    public static void loadAllAddress() {
        ADDRESS_LIST.clearList();
        var tempList = AddressList.getAll();
        var temp = tempList.getAddressList();
        for(var address : temp){
            ADDRESS_LIST.add(address);
        }
    }

    /**
     * This method is called to clear all the TextFields
     */
    private void clearForm() {
        this.lastNameTextField.setText(EMPTY_STRING);
        this.firstNameTextField.setText(EMPTY_STRING);
        this.middleInitialTextField.setText(EMPTY_STRING);
        this.streetTextField.setText(EMPTY_STRING);
        this.cityTextField.setText(EMPTY_STRING);
        this.stateTextField.setText(EMPTY_STRING);
        this.zipTextField.setText(EMPTY_STRING);
        this.teleTextField.setText(EMPTY_STRING);
        this.emailTextField.setText(EMPTY_STRING);

    }

    /**
     * This method is called to show an alert box when there is an error
     * @param title is the title string
     * @param header is the header string
     * @param text is the content string
     */
    private void showError(String title,String header,String text) {
        var alertDialog = new Alert(Alert.AlertType.ERROR);
        alertDialog.setTitle(title);
        alertDialog.setHeaderText(header);
        alertDialog.setContentText(text);
        alertDialog.showAndWait();
    }

    /**
     * This method is called to show an alert box to confirm an action
     * @param title is the title string
     * @param header is the header string
     * @param text is the content string
     */
    private void showAlertConformation(String title,String header, String text) {
        var alertDialog = new Alert(Alert.AlertType.CONFIRMATION);
        alertDialog.setTitle(title);
        alertDialog.setHeaderText(header);
        alertDialog.setContentText(text);
        alertDialog.showAndWait();
    }

    /**
     * This method is called to get an Optional String using a scanner
     * @param textField is the textfield that you want try and read
     * @return either Optional.of() or Optional.empty()
     */
    private Optional<String> getString(TextField textField){
        var reader = new Scanner(textField.getText());
        if(reader.hasNext()){
            return Optional.of(reader.next());
        } else {
            return Optional.empty();
        }
    }

    /**
     * This method is called to get the addressID from the a label
     * @param label is the label that is read.
     * @return either Optional.of() or Optional.empty()
     */
    private Optional<Integer> getAddressId(Label label){
        var reader = new Scanner(label.getText());
        if(reader.hasNextInt()){
            return Optional.of(reader.nextInt());
        } else {
            return Optional.empty();
        }
    }

    /**
     * This method is called to get the whole line from the a textfield
     * @param textField is the streetTextField to get the whole line
     * @return either Optional.of() or Optional.empty()
     */
    private Optional<String> getStreet(TextField textField){
        var reader = new Scanner(textField.getText());
        if(reader.hasNextLine()){
            return Optional.of(reader.nextLine());
        } else {
            return Optional.empty();
        }
    }

    /**
     * This method is called to get the MI or the State from the textfields
     * @param textField is the textfield we want to read
     * @param size is the size of the string that needs to be returned
     * @return either Optional.of() or Optional.empty()
     */
    public Optional<String> getMiddleInitialOrState(TextField textField, int size){
        var tempString = getString(textField);
        if(tempString.isPresent()){
            if(tempString.get().length() == size){
                return Optional.of(tempString.get());
            } else {
                return Optional.empty();
            }
        } // else doNothing()
        return tempString;
    }

    /**
     * This method is calle to get an INT value for telephone or zip code
     * @param textField is the field where it will read from
     * @param size is the size that the int needs to be
     * @return either Optional.of() or Optional.empty()
     */
    public Optional<Integer> getInt(TextField textField, int size){
        var reader = new Scanner(textField.getText());
        var tempZip = Integer.MAX_VALUE;
        if(reader.hasNextInt()){
            tempZip = reader.nextInt();
            var tempString = String.valueOf(tempZip);
            if(tempString.length() == size){
                if(tempZip > 0){
                    return Optional.of(tempZip);
                } else {
                    return Optional.empty();
                }
            } else {
                return Optional.empty();
            }
        } else {
            return Optional.empty();
        }
    }

    /**
     * This inner class was created to handle the ActionEvent when the insertButton is clicked
     */
    private class InsertButtonClickHandler implements EventHandler<ActionEvent> {
        @Override
        public void handle(ActionEvent actionEvent){
            var optionalLastName = getString(lastNameTextField);
            if(optionalLastName.isEmpty()){
                showError(INVALID,ERROR_LAST_NAME_HEADER,ERROR_LAST_NAME_CONTENT);
                return;
            } // else doNothing

            var optionalFirstName = getString(firstNameTextField);
            if(optionalFirstName.isEmpty()){
                showError(INVALID,ERROR_FIRST_NAME_HEADER,ERROR_FIRST_NAME_CONTENT);
                return;
            } // else doNothing

            var optionalMI = getMiddleInitialOrState(middleInitialTextField,MIDDLE_INITIAL_SIZE);
            if(optionalMI.isEmpty()){
                showError(INVALID,ERROR_MI_HEADER,ERROR_MI_CONTENT);
                return;
            } // else doNothing()

            var optionalStreet = getStreet(streetTextField);
            if(optionalStreet.isEmpty()){
                showError(INVALID,ERROR_STREET_HEADER,ERROR_STREET_CONTENT);
                return;
            } // else doNothing()

            var optionalCity = getString(cityTextField);
            if(optionalCity.isEmpty()){
                showError(INVALID,ERROR_CITY_HEADER,ERROR_CITY_CONTENT);
                return;
            } // else doNothing()

            var optionalState = getMiddleInitialOrState(stateTextField,STATE_SIZE);
            if(optionalState.isEmpty()){
                showError(INVALID,ERROR_STATE_HEADER,ERROR_STATE_CONTENT);
                return;
            } // else doNothing()

            var optionalZip =getInt(zipTextField,ZIP_SIZE);
            if(optionalZip.isEmpty()) {
                showError(INVALID,ERROR_ZIP_HEADER,ERROR_ZIP_CONTENT);
                return;
            } // else doNothing()

            var optionalTele = getInt(teleTextField,TELE_SIZE);
            if(optionalTele.isEmpty()){
                showError(INVALID,ERROR_TELE_HEADER,ERROR_TELE_CONTENT);
                return;
            } // else doNothing()

            var optionalEmail = getString(emailTextField);
            if(optionalEmail.isEmpty()){
                showError(INVALID,ERROR_EMAIL_HEADER,ERROR_EMAIL_CONTENT);
                return;
            } // else doNothing()

            var newAddress = new Address(optionalFirstName.get(),optionalMI.get().charAt(0),optionalLastName.get(),optionalStreet.get(),optionalCity.get(),optionalState.get().toUpperCase(),optionalZip.get(),optionalTele.get(),optionalEmail.get());
            if(newAddress.insertAddress()){
                showAlertConformation(INSERT_TITLE,INSERT_HEADER,INSERT_CONTENT);
                loadAllAddress();
                clearForm();
                currentRowLabel.setText(EMPTY_STRING);
            } else{
                showError(INVALID,ERROR_ADDRESS_HEADER,ERROR_ADDRESS_CONTENT);
            }
        }
    }

    /**
     * This inner class was created to handle the ActionEvent when the delete button is clicked
     */
    private class DeleteButtonClickHandler implements EventHandler<ActionEvent>{
        @Override
        public void handle(ActionEvent actionEvent) {

            var deleteAddress = Address.getById(getAddressId(currentRowLabel).get());
            if(deleteAddress.isEmpty()){
                showError(INVALID,ERROR_NOT_FOUND_HEADER,String.format(ERROR_NOT_FOUND_CONTENT,deleteAddress.get().getAddressId()));
                return;
            } // else doNothing()

            if(deleteAddress.get().deleteAddress()){
               showAlertConformation(DELETE_TITLE,DELETE_HEADER,DELETE_CONTENT);
                loadAllAddress();
                clearForm();
                currentRowLabel.setText(EMPTY_STRING);
            } else{
             showError(INVALID,ERROR_DELETE_HEADER,ERROR_DELETE_CONTENT);
            }
        }
    }

    /**
     * This inner class was created to handle the ActionEvent when the Update button is clicked
     */
    private class UpdateButtonClickHandler implements EventHandler<ActionEvent> {
        @Override
        public void handle(ActionEvent actionEvent){

            var updatedAddress = Address.getById(getAddressId(currentRowLabel).get());
            if(updatedAddress.isEmpty()){
                showError(INVALID,ERROR_NOT_FOUND_HEADER,String.format(ERROR_NOT_FOUND_CONTENT,updatedAddress.get().getAddressId()));
                return;
            }

            var optionalLastName = getString(lastNameTextField);
            if(optionalLastName.isEmpty()){
                showError(INVALID,ERROR_LAST_NAME_HEADER,ERROR_LAST_NAME_CONTENT);
                return;
            } // else doNothing

            var optionalFirstName = getString(firstNameTextField);
            if(optionalFirstName.isEmpty()){
                showError(INVALID,ERROR_FIRST_NAME_HEADER,ERROR_FIRST_NAME_CONTENT);
                return;
            } // else doNothing

            var optionalMI = getMiddleInitialOrState(middleInitialTextField,MIDDLE_INITIAL_SIZE);
            if(optionalMI.isEmpty()){
                showError(INVALID,ERROR_MI_HEADER,ERROR_MI_CONTENT);
                return;
            } // else doNothing()

            var optionalStreet = getStreet(streetTextField);
            if(optionalStreet.isEmpty()){
                showError(INVALID,ERROR_STREET_HEADER,ERROR_STREET_CONTENT);
                return;
            } // else doNothing()

            var optionalCity = getString(cityTextField);
            if(optionalCity.isEmpty()){
                showError(INVALID,ERROR_CITY_HEADER,ERROR_CITY_CONTENT);
                return;
            } // else doNothing()

            var optionalState = getMiddleInitialOrState(stateTextField,STATE_SIZE);
            if(optionalState.isEmpty()){
                showError(INVALID,ERROR_STATE_HEADER,ERROR_STATE_CONTENT);
                return;
            } // else doNothing()

            var optionalZip =getInt(zipTextField,ZIP_SIZE);
            if(optionalZip.isEmpty()) {
                showError(INVALID,ERROR_ZIP_HEADER,ERROR_ZIP_CONTENT);
                return;
            } // else doNothing()

            var optionalTele = getInt(teleTextField,TELE_SIZE);
            if(optionalTele.isEmpty()){
                showError(INVALID,ERROR_TELE_HEADER,ERROR_TELE_CONTENT);
                return;
            } // else doNothing()

            var optionalEmail = getString(emailTextField);
            if(optionalEmail.isEmpty()){
                showError(INVALID,ERROR_EMAIL_HEADER,ERROR_EMAIL_CONTENT);
                return;
            } // else doNothing()


            updatedAddress.get().setFirstName(optionalFirstName.get());
            updatedAddress.get().setLastName(optionalLastName.get());
            updatedAddress.get().setMiddleInitial(optionalMI.get().charAt(0));
            updatedAddress.get().setStreet(optionalStreet.get());
            updatedAddress.get().setCity(optionalCity.get());
            updatedAddress.get().setState(optionalState.get().toUpperCase());
            updatedAddress.get().setZip(optionalZip.get());
            updatedAddress.get().setTelephone(optionalTele.get());
            updatedAddress.get().setEmail(optionalEmail.get());

            if (updatedAddress.get().updateAddress()){
               showAlertConformation(UPDATE_TITLE,UPDATE_HEADER,UPDATE_CONTENT);
                loadAllAddress();
            } else {
                showError(INVALID,ERROR_UPDATE_HEADER,ERROR_UPDATE_CONTENT);
            }
        }
    }

    /**
     * This inner class was created to handle the ActionEvent when the Next button is clicked
     */
    private class NextButtonClickHandler implements EventHandler<ActionEvent>{
        @Override
        public void handle(ActionEvent actionEvent) {
            loadAllAddress();
            var addressList = ADDRESS_LIST.getAddressList();
            var currentAddressID = getAddressId(currentRowLabel);
            if(currentAddressID.isEmpty()){
                firstButtonClick();
                return;
            } // else doNothing()


            var currentAddress = ADDRESS_LIST.getAddress(currentAddressID.get());
            var currentAddressIndex = addressList.indexOf(currentAddress);
            if(currentAddressIndex == addressList.size()-1){
                showError(INVALID,ERROR_NEXT_HEADER,ERROR_NEXT_CONTENT);
                return;
            } else {
                var nextAddress = addressList.get(currentAddressIndex + 1);
                if(addressList.indexOf(nextAddress)>= addressList.size()){
                    showError(INVALID,ERROR_NEXT_HEADER,ERROR_NEXT_CONTENT);
                    return;
                } else {
                    lastNameTextField.setText(nextAddress.getLastName());
                    firstNameTextField.setText(nextAddress.getFirstName());
                    middleInitialTextField.setText(String.valueOf(nextAddress.getMiddleInitial()));
                    streetTextField.setText(nextAddress.getStreet());
                    cityTextField.setText(nextAddress.getCity());
                    stateTextField.setText(nextAddress.getState());
                    zipTextField.setText(String.valueOf(nextAddress.getZip()));
                    teleTextField.setText(String.valueOf(nextAddress.getTelephone()));
                    emailTextField.setText(nextAddress.getEmail());
                    currentRowLabel.setText(String.valueOf(nextAddress.getAddressId()));
                }
            }
        }
    }

    /**
     * This inner class was created to handle the ActionEvent when the Prior button is clicked
     */
    private class PriorButtonClickHandler implements EventHandler<ActionEvent>{
        @Override
        public void handle(ActionEvent actionEvent){
            loadAllAddress();
            var addressList = ADDRESS_LIST.getAddressList();
            var currentAddressId = getAddressId(currentRowLabel);
            if(currentAddressId.isEmpty()){
                showError(INVALID,ERROR_PRIOR_HEADER,ERROR_PRIOR_CONTENT);
                return;
            } // Else doNothing()

            var currentAddress = ADDRESS_LIST.getAddress(currentAddressId.get());
            var currentIndex = addressList.indexOf(currentAddress);
            if(currentAddress.getAddressId() == addressList.get(0).getAddressId()){
                showError(INVALID,ERROR_PRIOR_HEADER,ERROR_PRIOR_CONTENT);
                return;
            } else {
                var priorAddress = addressList.get(currentIndex - 1);
                if(addressList.indexOf(priorAddress) < 0){
                    showError(INVALID,ERROR_PRIOR_HEADER,ERROR_PRIOR_CONTENT);
                    return;
                } else {
                    lastNameTextField.setText(priorAddress.getLastName());
                    firstNameTextField.setText(priorAddress.getFirstName());
                    middleInitialTextField.setText(String.valueOf(priorAddress.getMiddleInitial()));
                    streetTextField.setText(priorAddress.getStreet());
                    cityTextField.setText(priorAddress.getCity());
                    stateTextField.setText(priorAddress.getState());
                    zipTextField.setText(String.valueOf(priorAddress.getZip()));
                    teleTextField.setText(String.valueOf(priorAddress.getTelephone()));
                    emailTextField.setText(priorAddress.getEmail());
                    currentRowLabel.setText(String.valueOf(priorAddress.getAddressId()));
                }
            }
        }
    }

    /**
     * Const for a InsertButtonClickHandler
     */
    private final InsertButtonClickHandler INSERT_BUTTON_CLICK_HANDLER = new InsertButtonClickHandler();

    /**
     * Const for a DeleteButtonClickHandler
     */
    private final DeleteButtonClickHandler DELETE_BUTTON_CLICK_HANDLER = new DeleteButtonClickHandler();

    /**
     * Const for a UpdateButtonClickHandler
     */
    private final UpdateButtonClickHandler UPDATE_BUTTON_CLICK_HANDLER = new UpdateButtonClickHandler();

    /**
     * Const for a NextButtonClickHandler
     */
    private final NextButtonClickHandler NEXT_BUTTON_CLICK_HANDLER = new NextButtonClickHandler();

    /**
     * Const for a PriorButtonClickHandler
     */
    private final PriorButtonClickHandler PRIOR_BUTTON_CLICK_HANDLER = new PriorButtonClickHandler();

    /**
     * This method was created to handle the event when the first button is clicked
     */
    private void firstButtonClick() {
        loadAllAddress();
        var addressList = ADDRESS_LIST.getAddressList();
        var firstAddress = addressList.get(0);
        lastNameTextField.setText(firstAddress.getLastName());
        firstNameTextField.setText(firstAddress.getFirstName());
        middleInitialTextField.setText(String.valueOf(firstAddress.getMiddleInitial()));
        streetTextField.setText(firstAddress.getStreet());
        cityTextField.setText(firstAddress.getCity());
        stateTextField.setText(firstAddress.getState());
        zipTextField.setText(String.valueOf(firstAddress.getZip()));
        teleTextField.setText(String.valueOf(firstAddress.getTelephone()));
        emailTextField.setText(firstAddress.getEmail());
        currentRowLabel.setText(String.valueOf(firstAddress.getAddressId()));
    }

    /**
     * This method was created to handle the event when the last button is clicked
     */
    private void lastButtonClick(){
        loadAllAddress();
        var addressList = ADDRESS_LIST.getAddressList();
        var lastAddress = addressList.get(addressList.size()-1);
        lastNameTextField.setText(lastAddress.getLastName());
        firstNameTextField.setText(lastAddress.getFirstName());
        middleInitialTextField.setText(String.valueOf(lastAddress.getMiddleInitial()));
        streetTextField.setText(lastAddress.getStreet());
        cityTextField.setText(lastAddress.getCity());
        stateTextField.setText(lastAddress.getState());
        zipTextField.setText(String.valueOf(lastAddress.getZip()));
        teleTextField.setText(String.valueOf(lastAddress.getTelephone()));
        emailTextField.setText(lastAddress.getEmail());
        currentRowLabel.setText(String.valueOf(lastAddress.getAddressId()));
    }


    @Override
    public void start(Stage stage) throws IOException {
        var pane = new GridPane();
        pane.setVgap(10);
        pane.setHgap(10);
        pane.setPadding(new Insets(10,10,10,10));

       var firstButton = new Button(FIRST_BUTTON);
        pane.add(firstButton,0,0);
        firstButton.setOnAction(e -> firstButtonClick());


       var nextButton = new Button(NEXT_BUTTON);
       pane.add(nextButton,1,0);
       nextButton.setOnAction(NEXT_BUTTON_CLICK_HANDLER);


       var priorButton = new Button(PRIOR_BUTTON);
       pane.add(priorButton,2,0);
       priorButton.setOnAction(PRIOR_BUTTON_CLICK_HANDLER);

       var lastButton = new Button(LAST_BUTTON);
       pane.add(lastButton,3,0);
       lastButton.setOnAction(e -> lastButtonClick());

       var insertButton = new Button(INSERT_TITLE);
       pane.add(insertButton,4,0);
       insertButton.setOnAction(INSERT_BUTTON_CLICK_HANDLER);

       var deleteButton = new Button(DELETE_TITLE);
       pane.add(deleteButton,5,0);
       deleteButton.setOnAction(DELETE_BUTTON_CLICK_HANDLER);

       var updateButton = new Button(UPDATE_TITLE);
       pane.add(updateButton,6,0);
       updateButton.setOnAction(UPDATE_BUTTON_CLICK_HANDLER);

       pane.add(new Label(LABEL_LAST_NAME),0,1);
       pane.add(this.lastNameTextField,1,1);
       pane.add(new Label(LABEL_FIRST_NAME),2,1);
       pane.add(this.firstNameTextField,3,1);
       pane.add(new Label(LABEL_MI),4,1);
       pane.add(middleInitialTextField,5,1);

       pane.add(new Label(LABEL_STREET),0,2);
       pane.add(this.streetTextField,1,2);

      pane.add(new Label(LABEL_CITY),0,3);
      pane.add(this.cityTextField,1,3);
      pane.add(new Label(LABEL_STATE),2,3);
      pane.add(this.stateTextField,3,3);
      pane.add(new Label(LABEL_ZIP),4,3);
      pane.add(this.zipTextField,5,3);

      pane.add(new Label(LABEL_TELE),0,4);
      pane.add(this.teleTextField,1,4);

      pane.add(new Label(LABEL_EMAIL),0,5);
      pane.add(this.emailTextField,1,5);

      pane.add(new Label(LABEL_CURRENT_ROW),0,6);
      pane.add(this.currentRowLabel,1,6);


       var scene = new Scene(pane);
        stage.setTitle(FORM_TITLE);
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}