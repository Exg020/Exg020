package com.example.hw5;

import org.tinylog.Logger;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * This class was created to implement the DAO interface for the Address Object. Using SQLite implementation
 */
public class SqliteAddressDAOImpl implements AddressDAO {
    /**
     * This is const string for the address id column
     */
    private static final String ID_COLUMN = "id";

    /**
     * This is the const string for the first name column
     */
    private static final String FIRST_NAME_COLUMN = "firstname";

    /**
     * This is the const string for the middle initial column
     */
    private static final String M_I_COLUMN = "mi";

    /**
     * This is the const string for the last name column
     */
    private static final String LAST_NAME_COLUMN = "lastname";

    /**
     * this is the const string for the street column
     */
    private static final String STREET_COLUMN = "street";

    /**
     * This is the const string for the city column
     */
    private static final String CITY_COLUMN = "city";

    /**
     * This is the const string for the state column
     */
    private static final String STATE_COLUMN = "state";

    /**
     * This is the const string for the zip column
     */
    private static final String ZIP_COLUMN = "zip";

    /**
     * This is the const string for telephone column
     */
    private static final String TELE_COLUMN = "telephone";

    /**
     * this is the const string for the email column
     */
    private static final String EMAIL_COLUMN = "email";

    /**
     * This is the const string for the insert address query
     */
    private static final String INSERT_ADDRESS_QUERY = "INSERT INTO Address (firstname,mi,lastname,street,city,state,zip,telephone,email) VALUES(?,?,?,?,?,?,?,?,?)";

    /**
     * This is the cont string for the delete address query
     */
    private static final String DELETE_ADDRESS_QUERY = "DELETE FROM Address WHERE id = ?";

    /**
     * This is the const string for the update address query
     */
    private static final String UPDATE_ADDRESS_QUERY = "UPDATE Address SET firstname = ? ,mi = ?, lastname = ?, street = ?, city = ?, state = ?, zip = ?, telephone = ?, email = ? WHERE id = ?";

    /**
     * This is the const string for the select all query
     */
    private static final String SELECT_ALL_QUERY = "SELECT id,firstname,mi,lastname,street,city,state,zip,telephone,email FROM Address";

    /**
     * This is the const string for the select by id query
     */
    private static final String SELECT_BY_ID_QUERY = "SELECT id,firstname,mi,lastname,street,city,state,zip,telephone,email FROM Address WHERE id = ?";

    /**
     * This method uses a prepared statement to add an Address into the Address table
     * @param address is the Address Object
     * @return 1 if the prepared statement was successful inserting 1 row
     * @throws DAOException if there is a SQLException error. Error will be logged
     */
    @Override
    public boolean insertAddress(Address address) throws DAOException {
        Logger.info(String.format("Inserting an Address object into the Address.db file - first name -%s",address.toString()));
        try(var connection = DriverManager.getConnection(SqliteDAOFactory.URL);
        var statement = connection.prepareStatement(INSERT_ADDRESS_QUERY)) {
            statement.setString(1,address.getFirstName());
            statement.setString(2,String.valueOf(address.getMiddleInitial()));
            statement.setString(3,address.getLastName());
            statement.setString(4,address.getStreet());
            statement.setString(5,address.getCity());
            statement.setString(6,address.getState());
            statement.setString(7,String.valueOf(address.getZip()));
            statement.setString(8, String.valueOf(address.getTelephone()));
            statement.setString(9,address.getEmail());
            return statement.executeUpdate() == 1;
        }catch (SQLException sqlException){
            Logger.error(String.format("Unable to insert Address for contact %s",address.getFirstName()));
            System.err.println(sqlException.getMessage());
            throw new DAOException(sqlException.getMessage());
        }
    }

    /**
     * This method uses a prepared statement to update an Address in the Address table
     * @param address is the Address Object
     * @return 1 if the prepared statement was successful updating 1 row
     * @throws DAOException if there is a SQLException error. Error will be logged
     */
    @Override
    public boolean updateAddress(Address address) throws DAOException {
     Logger.info(String.format("Updating the address where the id is %d",address.getAddressId()));
     try(var connection = DriverManager.getConnection(SqliteDAOFactory.URL);
     var statement = connection.prepareStatement(UPDATE_ADDRESS_QUERY)){
         statement.setString(1, address.getFirstName());
         statement.setString(2,String.valueOf(address.getMiddleInitial()));
         statement.setString(3, address.getLastName());
         statement.setString(4,address.getStreet());
         statement.setString(5,address.getCity());
         statement.setString(6,address.getState());
         statement.setString(7,String.valueOf(address.getZip()));
         statement.setString(8,String.valueOf(address.getTelephone()));
         statement.setString(9,address.getEmail());
         statement.setInt(10,address.getAddressId());
         return statement.executeUpdate() ==1;
     } catch (SQLException sqlException){
         Logger.error(String.format("Unable to update the address with update query - %s",UPDATE_ADDRESS_QUERY));
         System.err.println(sqlException.getMessage());
         throw new DAOException(sqlException.getMessage());
     }
    }

    /**
     * This method uses a prepared statement to delete an Address from the Address table
     * @param address is the Address Object
     * @return 1 if the prepared statement was successful deleting 1 row
     * @throws DAOException if there is a SQLException error. Error will be logged
     */
    @Override
    public boolean deleteAddress(Address address) throws DAOException {
        Logger.info(String.format("Deleting %s Address from file",address.getFirstName()));
        try(var connection = DriverManager.getConnection(SqliteDAOFactory.URL);
        var statement = connection.prepareStatement(DELETE_ADDRESS_QUERY)){
            statement.setInt(1,address.getAddressId());
            return statement.executeUpdate() == 1;
        } catch (SQLException sqlException){
            Logger.error(String.format("Unable to delete Address for the contact %s",address.getFirstName()));
            System.err.println(sqlException.getMessage());
            throw new DAOException(sqlException.getMessage());
        }
    }

    /**
     * This method uses the select complete query in a prepared statement to create a AddressList of all Addresses in the Address table
     * @return a new AddressList
     * @throws DAOException if there is a SqlException error. Error will be logged
     */
    @Override
    public AddressList getAll() throws DAOException {
        Logger.info(String.format("Selecting all the Addresses from the file using %s ",SELECT_ALL_QUERY));
        try(var connection = DriverManager.getConnection(SqliteDAOFactory.URL);
        var statement = connection.createStatement();
        var resultSet = statement.executeQuery(SELECT_ALL_QUERY)){
            var list = new ArrayList<Address>();
            while(resultSet.next()){
                var tempMi = resultSet.getString(M_I_COLUMN);
                list.add(new Address(resultSet.getInt(ID_COLUMN),resultSet.getString(FIRST_NAME_COLUMN),tempMi.charAt(0),resultSet.getString(LAST_NAME_COLUMN),resultSet.getString(STREET_COLUMN),resultSet.getString(CITY_COLUMN),resultSet.getString(STATE_COLUMN),
                        resultSet.getInt(ZIP_COLUMN),resultSet.getInt(TELE_COLUMN),resultSet.getString(EMAIL_COLUMN)));
            }
            return new AddressList(list);
        } catch (SQLException sqlException){
            Logger.error(String.format("Unable to select all the addresses using %s",SELECT_ALL_QUERY));
            System.err.println(sqlException.getMessage());
            throw new DAOException(sqlException.getMessage());
        }
    }

    /**
     * This method uses a prepared statement to get an Address from the Address table where the id matches
     * @param id is the address id for the address
     * @return 1 if the prepared statement was successful getting one row
     * @throws DAOException if there is a SQLException error. Error will be logged
     */
    @Override
    public Address getById(int id) throws DAOException {
        Logger.info(String.format("Selecting address by address id - %d",id));
        try(var connection = DriverManager.getConnection(SqliteDAOFactory.URL);
        var statement = connection.prepareStatement(SELECT_BY_ID_QUERY)){
            statement.setInt(1,id);
            try(var resultSet = statement.executeQuery()){
                if(!resultSet.next()){
                    Logger.info(String.format("No Addresses found with the id - %d",id));
                    throw new NotFoundException(String.format("Address not found with id - %d",id));
                } else {
                    var tempMi = resultSet.getString(M_I_COLUMN);
                    return new Address(resultSet.getInt(ID_COLUMN),resultSet.getString(FIRST_NAME_COLUMN),tempMi.charAt(0),resultSet.getString(LAST_NAME_COLUMN),resultSet.getString(STREET_COLUMN),resultSet.getString(CITY_COLUMN),resultSet.getString(STATE_COLUMN),
                            resultSet.getInt(ZIP_COLUMN),resultSet.getInt(TELE_COLUMN),resultSet.getString(EMAIL_COLUMN));
                }
            }
        } catch (SQLException sqlException){
            Logger.error(String.format("Unable to get the address by id %d",id));
            System.err.println(sqlException.getMessage());
            throw new DAOException(sqlException.getMessage());
        }
    }
}
