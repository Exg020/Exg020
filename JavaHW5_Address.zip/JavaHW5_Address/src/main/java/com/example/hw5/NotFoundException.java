package com.example.hw5;
/**
 * This class was created to make custom Runtime exception. In this case it will be thrown if the queries where correct but no item was found
 */
public class NotFoundException extends RuntimeException{
    /**
     * Constructs and initializes the class
     * @param message that will be thrown
     */
    public NotFoundException(String message) {
        super(message);
    }
}
