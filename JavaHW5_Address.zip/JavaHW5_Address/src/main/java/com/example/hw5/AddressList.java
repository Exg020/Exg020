package com.example.hw5;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * This class was created to create an ArrayList of Addresses
 */
public class AddressList {

    /**\
     * Const for a List of Addresses.
     */
    private final List<Address> addressList = new ArrayList<>();

    /**
     * The const DAO for the Address object DAO
     */
    private static final AddressDAO DAO = DAOFactory.getDAOFactory(DAOFactory.SQLITE).getAddressDAO();

    /**
     * A private AddressList that is used to get all the addresses from the file
     */
    private AddressList() {}

    /**
     * Constructs and initializes an AddressList with its values
     * @param addresses is the collection of Addresses that needs to be added to the AddressList object
     */
    public AddressList(Collection<Address> addresses){
        this.addressList.addAll(addresses);
    }

    /**
     * This method is used to add an Address to the addressList object
     * @param address object
     */
    public void add(Address address){
        this.addressList.add(address);
    }


    /**
     * This method is used to remove all the addresses from the addressList
     */
    public void clearList() {
        this.addressList.removeAll(addressList);
    }

    /**
     * This method takes an int value and returns the address object with the matching id
     * @param id is used to compare to the addressId int value
     * @return either an address with a matching id or null
     */
    public Address getAddress(int id){
        for(var address : this.addressList){
            if(address.getAddressId() == id){
                return address;
            } // else do Nothing
        }
        return null;
    }

    /**
     * This method is used to return an ArrayList of the AddressList
     * @return ArrayList of this
     */
    public List<Address> getAddressList() {
        return new ArrayList<>(this.addressList);
    }

    /**
     * This method is used to return the AddressList as a Stringbuilder. This makes it easier to print out the list
     * @return builder.toString()
     */
    public String toString() {
        var builder = new StringBuilder();
        for(var address : this.addressList){
            builder.append(address.getAddressId()).append(" | ").append(address.getFirstName()).append(" ").append(address.getLastName());
        }
        return builder.toString();
    }

    /**
     * This method is used to get all the addresses from the database
     * @return either a new AddressList if there is exceptions or calls the DAO.getAll()
     */
    public static AddressList getAll() {
        try{
            return DAO.getAll();
        } catch (DAOException daoException){
            return new AddressList();
        }
    }

}
