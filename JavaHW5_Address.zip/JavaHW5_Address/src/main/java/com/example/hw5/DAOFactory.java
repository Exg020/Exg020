package com.example.hw5;
/**
 * This abstract class created to have methods be overridden in their own concrete factories
 */
public abstract class DAOFactory {

    /**
     * This const for SQLITE
     */
    public static final int SQLITE = 1;

    /**
     * This method will be overridden in the concrete factories
     * @return AddressDAO
     */
    public abstract AddressDAO getAddressDAO();

    /**
     * This method is used to select the correct concrete factory to use
     * @param whichFactory is an int value for the correct factory. In this project it will always be 1
     * @return DAOFactory
     */
    public static DAOFactory getDAOFactory(int whichFactory){
        if(whichFactory == SQLITE){
            return new SqliteDAOFactory();
        } else {
            throw new IllegalArgumentException("Invalid factory");
        }
    }

}
