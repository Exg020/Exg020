package com.example.hw5;

/**
 * This is the DAO for the Address Object
 */
public interface AddressDAO {

    /**
     * This boolean will be overridden by the AddressDAOImpl Class
     * @param address is the Address object
     * @return either true or false
     * @throws DAOException if the method fails when trying to perform actions
     */
    boolean insertAddress(Address address) throws DAOException;

    /**
     * This boolean will be overridden by the AddressDAOImpl Class
     * @param address is the Address object
     * @return either true or false
     * @throws DAOException if the method fails when trying to perform actions
     */
    boolean updateAddress(Address address) throws DAOException;

    /**
     * This boolean will be overridden by the AddressDAOImpl Class
     * @param address is the Address object
     * @return either true or false
     * @throws DAOException if the method fails when trying to perform actions
     */
    boolean deleteAddress(Address address) throws DAOException;

    /**
     * This method will be overridden by the AddressDAOImpl Class
     * @return a AddressList with all the addresses in the file
     * @throws DAOException if the method fails when trying to communicate with the file
     */
    AddressList getAll() throws DAOException;

    /**
     * This method will be overridden by the AddressDAOImpl Class
     * @param id is the int value of the id
     * @return an Address with the id that matches the id param
     * @throws DAOException if the method fails when trying to communicate with the file
     */
    Address getById(int id) throws DAOException;

}
